const regButton = document.getElementById("regButton");
regButton.addEventListener("click", async (e) => {
    e.preventDefault();
    const email = document.getElementById("email").value;
    const nickname = document.getElementById("nickname").value;
    const password = document.getElementById("password").value;

    if (!validateEmail(email)) {
        alert("Введите корректный email");
        return;
    }
    if (password.length < 6) {
        alert("Пароль должен быть не менее 6 символов");
        return;
    }
    if (!validateNickname(nickname)) {
        alert("Имя пользователя не должно содержать запрещённые символы");
        return;
    }
    const response = await fetch("/register", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, nickname, password }),
    });

    if (response.ok) {
        const data = await response.json();
        localStorage.setItem("token", data.token);
        window.location.href = "/profile";
    } else {
        const data = await response.json();
        alert(data.message);
    }
});

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validateNickname(nickname) {
    const re = /^[a-zA-Z0-9_]+$/;
    return re.test(nickname);
}
