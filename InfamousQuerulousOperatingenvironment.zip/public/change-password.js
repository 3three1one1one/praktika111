const form = document.createElement("form");
form.method = "POST";
form.action = "/change-password";

const oldPasswordInput = document.createElement("input");
oldPasswordInput.type = "password";
oldPasswordInput.placeholder = "Старый пароль";
oldPasswordInput.name = "old_password";
oldPasswordInput.id = "old_password"; 

const newPasswordInput = document.createElement("input");
newPasswordInput.type = "password";
newPasswordInput.placeholder = "Новый пароль";
newPasswordInput.name = "new_password";
newPasswordInput.id = "new_password"; 

const submitButton = document.createElement("button");
submitButton.type = "submit";
submitButton.textContent = "Изменить пароль";

form.appendChild(oldPasswordInput);
form.appendChild(newPasswordInput);
form.appendChild(submitButton);

document.body.appendChild(form);

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  try {
    const oldPassword = document.getElementById("old_password").value;
    const newPassword = document.getElementById("new_password").value;

    const response = await fetch("/change-password", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        old_password: oldPassword,
        new_password: newPassword,
      }),
    });

    if (response.ok) {
      const data = await response.json();
      alert(data.message);
    } else {
      const data = await response.json();
      alert(data.message);
    }
  } catch (error) {
    console.error(error);
    alert("Ошибка: не удалось получить значения из формы.");
  }
});
