const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const { Sequelize, DataTypes } = require("sequelize");

const sequelize = new Sequelize({
    dialect: "sqlite",
    storage: "public/text.sqlite",
});

const User = sequelize.define("User", {
    email: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    nickname: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    dataregistration: {
        type: DataTypes.STRING,
        allowNull: false,
    },
});

sequelize.sync();

const app = express();

app.use(express.static("public"));
app.use(cors());
app.use(express.json());

const authenticateJWT = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (authHeader) {
        const token = authHeader.split(" ")[1];

        jwt.verify(token, "2315", (err, user) => {
            if (err) {
                return res.status(403).json({ message: "Доступ запрещён" });
            }

            req.user = user;
            next();
        });
    } else {
        res.status(401).json({
            message: "Токен не предоставлен. Ты не авторизован",
        });
    }
};

app.get("/profile", authenticateJWT, async (request, response) => {
    let email = request.user.email;
    let user = await User.findOne({ where: { email: email } });
    console.log(user.dataregistration);
    response.send({
        email: user.email,
        nickname: user.nickname,
        dataregistration: user.dataregistration,
    });
});

app.post("/register", async (request, response) => {
    const { email, nickname, password } = request.body;
    let user = await User.findOne({ where: { email: email } });
    if (user != null)
        return response
            .status(400)
            .json({ message: "Этот email уже используется" });

    let data = new Date().toLocaleDateString();
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    user = await User.create({
        email,
        nickname,
        password: hashedPassword,
        dataregistration: data,
    });

    let token = jwt.sign({ email: email }, "2315", { expiresIn: "30m" });
    response.send({ token });
});

app.post("/login", async (request, response) => {
    const { email, password } = request.body;

    let user = await User.findOne({ where: { email: email } });
    if (user == null) {
        return response.sendStatus(404);
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return response.sendStatus(400);

    let token = jwt.sign({ email: email }, "2315", { expiresIn: "30m" });
    response.send({ token });
});

app.get("/hello", authenticateJWT, (request, response) => {
    response.send("Привет авторизованный пользователь");
});

app.post("/change-password", authenticateJWT, async (request, response) => {
    const { old_password, new_password } = request.body;
    let email = request.user.email;
    let user = await User.findOne({ where: { email: email } });
    const isMatch = await bcrypt.compare(old_password, user.password);
    if (!isMatch) {
        return response.status(400).json({ message: "Неверный старый пароль" });
    }
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(new_password, salt);
    user.password = hashedPassword;
    await user.save();
    response.send({ message: "Пароль успешно изменён" });
});

app.listen(3000, () => {
    console.log("Негры работают.........");
});
